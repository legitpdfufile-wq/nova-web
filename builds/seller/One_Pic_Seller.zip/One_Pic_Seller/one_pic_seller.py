from __future__ import annotations

import base64
import csv
import io
import json
import mimetypes
import os
import re
import shutil
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
JOBS = DATA / "jobs"
WWW = ROOT / "www"
PORT = 3955
OLLAMA = "http://127.0.0.1:11434/api/chat"
VISION_MODEL = os.environ.get("ONE_PIC_VISION_MODEL", "qwen3-vl:2b")
MAX_UPLOAD = 18 * 1024 * 1024
for folder in (DATA, JOBS):
    folder.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now().isoformat(timespec="seconds")


def atomic_json(path: Path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temp.replace(path)


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._ -]+", "", value).strip(" .")
    return value[:80] or "item"


def enhance_image(source: Path, destination: Path):
    try:
        from PIL import Image, ImageEnhance, ImageOps
        image = Image.open(source).convert("RGB")
        # A marketplace-sized preview is enough for identification and keeps
        # local vision responsive on laptops without a dedicated GPU.
        image.thumbnail((900, 900))
        image = ImageOps.autocontrast(image, cutoff=1)
        image = ImageEnhance.Color(image).enhance(1.04)
        image = ImageEnhance.Sharpness(image).enhance(1.12)
        image.save(destination, "JPEG", quality=84, optimize=True)
        return "Enhanced: crop preserved, exposure balanced, color and sharpness gently improved."
    except Exception as exc:
        shutil.copy2(source, destination)
        return f"Original preserved because optional image enhancement was unavailable: {exc}"


def ollama_listing(image_path: Path, facts: dict):
    prompt = """You are a careful resale listing assistant. Inspect only the supplied photo and user facts.
Return strict JSON with keys: item_type, brand, model, condition_observations (array), title,
description, keywords (array), unknowns (array), price_low, price_mid, price_high, pricing_basis.
Never infer a brand or exact model from visual resemblance alone. A logo or seller fact is required.
Never invent size, condition, authenticity, function, market comps, or price evidence.
If there are no verified comparable-sale prices, pricing_basis must say 'AI estimate, verify with sold listings'.
Prices must be conservative USD numbers for a generic used item of the observed type—not a guessed premium model.
Description must separate observed facts from user-provided facts.
User facts: """ + json.dumps(facts)
    encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
    payload = {"model": VISION_MODEL, "stream": False, "think": False, "format": "json", "messages": [
        {"role": "user", "content": prompt, "images": [encoded]}
    ], "options": {"temperature": 0.15, "num_predict": 700}}
    request = urllib.request.Request(OLLAMA, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=150) as response:
        outer = json.loads(response.read().decode())
    message = outer.get("message", {})
    raw = (message.get("content") or message.get("thinking") or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I | re.S)
    match = re.search(r"\{.*\}", raw, flags=re.S)
    if not match: raise ValueError("Vision engine returned no usable listing")
    result = json.loads(match.group(0))
    for key in ("price_low", "price_mid", "price_high"):
        try: result[key] = round(float(result.get(key, 0)), 2)
        except Exception: result[key] = 0
    # Visual resemblance is not proof of brand/model. Remove unsupported identity claims.
    supplied = (facts.get("known_facts", "") + " " + facts.get("item_hint", "")).lower()
    for field in ("brand", "model"):
        value = str(result.get(field, "")).strip()
        if value and value.lower() not in supplied:
            result[field] = "Unknown"
    item_type = str(result.get("item_type") or facts.get("item_hint") or "Item").strip()
    if result.get("brand") == "Unknown" and result.get("model") == "Unknown":
        result["title"] = f"{item_type.title()} - details to verify"
    result["pricing_basis"] = "AI estimate only—verify against current sold listings before posting."
    result["engine"] = VISION_MODEL
    return result


def fallback_listing(facts: dict):
    item = facts.get("item_hint") or "Item"
    notes = facts.get("known_facts") or "No seller-supplied details yet."
    return {
        "item_type": item, "brand": "Unknown", "model": "Unknown",
        "condition_observations": ["Photo saved for human review"],
        "title": f"{item} - details to verify",
        "description": f"Seller-provided facts: {notes}\n\nPlease verify brand, model, dimensions, condition, and operation before publishing.",
        "keywords": [], "unknowns": ["Brand", "Model", "Exact condition", "Dimensions", "Working status"],
        "price_low": 0, "price_mid": 0, "price_high": 0,
        "pricing_basis": "No verified market evidence. Add sold comparables before pricing.",
        "engine": "safe fallback"
    }


def create_job(filename: str, content: bytes, facts: dict):
    jid = datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
    folder = JOBS / jid
    folder.mkdir()
    suffix = Path(filename).suffix.lower() if Path(filename).suffix else ".jpg"
    original = folder / ("original" + suffix)
    original.write_bytes(content)
    cleaned = folder / "listing_photo.jpg"
    cleanup_note = enhance_image(original, cleaned)
    try:
        listing = ollama_listing(cleaned, facts)
        ai_status = "VISION VERIFIED"
    except Exception as exc:
        listing = fallback_listing(facts)
        ai_status = "NEEDS REVIEW"
        listing["ai_error"] = str(exc)
    record = {
        "id": jid, "created": now(), "updated": now(), "status": "DRAFT",
        "proof": [], "original": original.name, "cleaned": cleaned.name,
        "cleanup_note": cleanup_note, "facts": facts, "listing": listing,
        "ai_status": ai_status,
        "outlets": {name: {"status": "NOT CONNECTED", "receipt": None} for name in
                    ["Facebook Marketplace", "eBay", "Etsy", "Craigslist", "Payhip", "Mercari"]},
        "orders": []
    }
    atomic_json(folder / "job.json", record)
    make_export(record, folder)
    return record


def make_export(record, folder: Path):
    listing = record["listing"]
    export = folder / "SELLING_PACKAGE"
    export.mkdir(exist_ok=True)
    (export / "LISTING.txt").write_text(
        f"TITLE\n{listing.get('title','')}\n\nDESCRIPTION\n{listing.get('description','')}\n\n"
        f"PRICE RANGE\n${listing.get('price_low',0)} / ${listing.get('price_mid',0)} / ${listing.get('price_high',0)}\n\n"
        f"PRICING BASIS\n{listing.get('pricing_basis','')}\n\nUNKNOWNS\n- " + "\n- ".join(listing.get("unknowns", [])), encoding="utf-8")
    shutil.copy2(folder / record["cleaned"], export / "listing_photo.jpg")
    with (export / "marketplace_import.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["title", "description", "price", "quantity", "status"])
        writer.writeheader(); writer.writerow({"title": listing.get("title", ""), "description": listing.get("description", ""), "price": listing.get("price_mid", 0), "quantity": 1, "status": "DRAFT"})
    atomic_json(export / "listing.json", record)
    (export / "READ_BEFORE_POSTING.txt").write_text(
        "Nothing in this package proves a marketplace post, sale, payment, or shipment.\n"
        "Verify unknown facts and sold-listing comparisons. Approve the final draft before posting.\n"
        "A platform is POSTED only after its API or a saved receipt confirms success.\n", encoding="utf-8")


def all_jobs():
    rows = []
    for path in sorted(JOBS.glob("*/job.json"), reverse=True):
        try: rows.append(json.loads(path.read_text(encoding="utf-8")))
        except Exception: pass
    return rows


class Handler(BaseHTTPRequestHandler):
    def json(self, value, code=200):
        data = json.dumps(value).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store"); self.send_header("Content-Length", str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/jobs": return self.json(all_jobs())
        if parsed.path.startswith("/jobs/"):
            rel = parsed.path.lstrip("/")
            target = (DATA / rel).resolve()
            if DATA.resolve() not in target.parents or not target.is_file(): return self.send_error(404)
            data = target.read_bytes(); self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        target = WWW / (parsed.path.lstrip("/") or "index.html")
        if not target.is_file(): return self.send_error(404)
        data = target.read_bytes(); self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "text/plain")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        if self.path == "/api/open-package":
            try:
                payload = json.loads(self.rfile.read(length) if length else b"{}")
                jid = re.sub(r"[^A-Za-z0-9_]", "", payload.get("id", ""))
                target = JOBS / jid / "SELLING_PACKAGE"
                if not target.is_dir(): raise ValueError("Selling package not found")
                os.startfile(str(target)); return self.json({"ok": True})
            except Exception as exc: return self.json({"ok": False, "error": str(exc)}, 400)
        if self.path != "/api/create": return self.json({"ok": False}, 404)
        if length <= 0 or length > MAX_UPLOAD * 1.5: return self.json({"ok": False, "error": "Upload is missing or too large"}, 400)
        try:
            payload = json.loads(self.rfile.read(length))
            content = base64.b64decode(payload["image"])
            if len(content) > MAX_UPLOAD: raise ValueError("Image exceeds 18 MB")
            record = create_job(safe_name(payload.get("filename", "photo.jpg")), content, payload.get("facts", {}))
            self.json({"ok": True, "job": record})
        except Exception as exc: self.json({"ok": False, "error": str(exc)}, 400)

    def log_message(self, fmt, *args):
        print(f"[{now()}] {fmt % args}")


def main():
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}"
    print(f"ONE PIC SELLER ONLINE: {url}")
    threading.Timer(1, lambda: webbrowser.open(url)).start()
    server.serve_forever()


if __name__ == "__main__": main()
