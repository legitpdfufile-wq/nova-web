"""Maintained local server, retaining the original photo/listing engine."""
import base64, io, json, os, re, secrets, threading, uuid, zipfile
from pathlib import Path
from urllib.parse import urlparse
from PIL import Image, ImageOps, ImageEnhance
import one_pic_seller as core

core.DATA=Path(os.environ.get('ONE_PIC_DATA',str(core.ROOT/'data')))
core.JOBS=core.DATA/'jobs';core.JOBS.mkdir(parents=True,exist_ok=True)
core.VISION_MODEL=os.environ.get('ONE_PIC_VISION_MODEL','qwen3-vl:2b-instruct')
TOKEN=secrets.token_urlsafe(32); TASKS={}; AI_LOCK=threading.Lock(); SAVE_LOCK=threading.Lock()
def enhance(source,destination):
    with Image.open(source) as raw:
        image=ImageOps.exif_transpose(raw).convert('RGB');image.thumbnail((1600,1600))
        image=ImageOps.autocontrast(image,cutoff=0.5)
        image=ImageEnhance.Sharpness(image).enhance(1.08)
        image.save(destination,'JPEG',quality=92,optimize=True)
    return 'Separate JPEG: orientation corrected, exposure and sharpness gently adjusted; original retained.'
core.enhance_image=enhance

class Handler(core.Handler):
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/status': return self.json({'local':True,'token':TOKEN,'model':core.VISION_MODEL,'automatic_monitoring':False})
        if path.startswith('/api/task/'): return self.json(TASKS.get(path.rsplit('/',1)[-1],{'status':'missing'}))
        if path.startswith('/api/package/'):
            jid=path.rsplit('/',1)[-1]
            if not re.fullmatch(r'[A-Za-z0-9_]+',jid):return self.send_error(404)
            folder=core.JOBS/jid
            if not (folder/'job.json').is_file():return self.send_error(404)
            with SAVE_LOCK: core.make_export(json.loads((folder/'job.json').read_text(encoding='utf-8')),folder)
            buf=io.BytesIO()
            with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
                for f in (folder/'SELLING_PACKAGE').iterdir():z.write(f,f.name)
            data=buf.getvalue();self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Disposition','attachment; filename="selling-package.zip"');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if not path.startswith(('/api/','/jobs/')):
            target=(core.WWW/(path.lstrip('/') or 'index.html')).resolve()
            if core.WWW.resolve() not in target.parents:return self.send_error(404)
        return super().do_GET()

    def do_POST(self):
        if self.headers.get('X-One-Pic-Token')!=TOKEN:return self.json({'error':'Reload the app to continue'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=core.MAX_UPLOAD*1.5:raise ValueError('Upload must be under 18 MB')
            data=json.loads(self.rfile.read(length))
            if self.path=='/api/create':
                image=base64.b64decode(data['image'],validate=True)
                if len(image)>core.MAX_UPLOAD:raise ValueError('Photo exceeds 18 MB')
                with Image.open(io.BytesIO(image)) as check:
                    if check.format not in ('JPEG','PNG','WEBP','GIF','BMP') or check.width*check.height>25000000:raise ValueError('Use JPG, PNG, WebP, GIF or BMP under 25 megapixels')
                    check.verify()
                facts={k:str(data.get('facts',{}).get(k,''))[:4000] for k in ('item_hint','known_facts','category')}
                tid=uuid.uuid4().hex;TASKS[tid]={'status':'working','message':'Waiting for local AI'}
                def run():
                    try:
                        with AI_LOCK:
                            TASKS[tid]['message']='Local AI is inspecting your photo and preparing a draft'
                            job=core.create_job(core.safe_name(data.get('filename','photo.jpg')),image,facts)
                            job['ai_status']='AI DRAFT — REVIEW' if job['ai_status']=='VISION VERIFIED' else 'AI UNAVAILABLE — FACTS ONLY'
                            core.atomic_json(core.JOBS/job['id']/'job.json',job)
                        TASKS[tid]={'status':'done','job':job}
                    except Exception as exc:TASKS[tid]={'status':'error','error':str(exc)}
                threading.Thread(target=run,daemon=True).start();return self.json({'ok':True,'task':tid},202)
            if self.path=='/api/save':
                jid=str(data.get('id',''))
                if not re.fullmatch(r'[A-Za-z0-9_]+',jid):raise ValueError('Invalid item ID')
                with SAVE_LOCK:
                    folder=core.JOBS/jid;path=folder/'job.json';job=json.loads(path.read_text(encoding='utf-8'))
                    for k in ('title','description'):job['listing'][k]=str(data.get(k,job['listing'].get(k,'')))[:12000]
                    price=float(data.get('price',0))
                    if not 0<=price<=10000000:raise ValueError('Enter a valid price')
                    status=data.get('status','DRAFT')
                    if status not in ('DRAFT','READY','LISTED BY OWNER','SOLD BY OWNER','ARCHIVED'):raise ValueError('Invalid status')
                    url=str(data.get('listing_url',''))[:2000]
                    if url and urlparse(url).scheme not in ('https','http'):raise ValueError('Use an http or https listing link')
                    follow=str(data.get('follow_up',''))
                    if follow and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',follow):raise ValueError('Invalid follow-up date')
                    job['listing']['price_mid']=price;job.update(status=status,listing_url=url,follow_up=follow,updated=core.now())
                    core.atomic_json(path,job);core.make_export(job,folder)
                return self.json({'ok':True,'job':job})
            return self.json({'error':'Unknown action'},404)
        except Exception as exc:return self.json({'error':str(exc)},400)

if __name__=='__main__':
    port=int(os.environ.get('ONE_PIC_PORT','3956'))
    print(f'ONE PIC SELLER http://127.0.0.1:{port}',flush=True)
    core.ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
