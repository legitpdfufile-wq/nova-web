ONE PIC SELLER — NOVA COLLECTION

FREE BROWSER WORKSPACE
Open https://nova-collection.mik-luvin-1308.chatgpt.site/builds/seller/
Choose a photo and supply known facts. Edit and save a real listing package.
Download JPEG, TXT, JSON and generic CSV as a ZIP. Keep saved items and follow-up dates.
Browser drafts use your supplied facts, not image-recognition AI. Browser data can be cleared;
use Back up board. Restoring a backup keeps existing items and adds new IDs.

LOCAL AI EDITION FOR WINDOWS
Requirements: Python 3.11+ with Pillow; Ollama running locally with qwen3-vl:2b-instruct.
If you already have these, extract and double-click START ONE PIC SELLER.bat.
If Pillow is missing, install it yourself with: python -m pip install -r requirements.txt
The launcher never installs anything automatically or starts a paid service.
Open http://127.0.0.1:3956. Keep the terminal open while using local AI.
Local AI may take a few minutes. When unavailable, the app explicitly gives a facts-only draft.
Review generated content, unknowns, and suggested prices. AI estimates are not verified sold comps.
Original photo is retained under data/jobs; separate listing JPEG is gently enhanced.

POSTING AND FOLLOW-UP
Choose category for recommended marketplace links. Copy listing text or download your package.
Opening a marketplace is NOT posting. Review and post from your own account.
Enter the listing URL and mark LISTED BY OWNER; this is your own record, not a platform receipt.
Set follow-up dates; due items are highlighted while viewing the board.
No buyer-message, order, automatic cross-posting, automatic delisting, or background marketplace
monitor is connected. No paid monitoring or subscription is offered in this release.
CSV is a generic export; follow your marketplace's own import specifications.

PRIVACY AND BACKUP
The Python server binds to 127.0.0.1 only. Photos go to local Ollama, not an online AI provider.
Do not expose the local server to the internet. Keep a backup of your data folder.
The public workspace stores photos in your browser; it does not upload them.
This ZIP contains no owner's photos, jobs, passwords, account tokens or private memory.
