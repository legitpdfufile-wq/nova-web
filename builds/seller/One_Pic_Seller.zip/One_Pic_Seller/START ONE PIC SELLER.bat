@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -c "import PIL" >nul 2>&1
  if not errorlevel 1 (
    start "" http://127.0.0.1:3956
    py -3 seller_server.py
    goto end
  )
)
python -c "import PIL" >nul 2>&1
if not errorlevel 1 (
  start "" http://127.0.0.1:3956
  python seller_server.py
  goto end
)
echo Python 3.11 or newer with Pillow is required.
echo See READ_ME_FIRST.txt. Nothing has been installed or charged.
:end
pause
