@echo off
start "" "%~dp0PLAY_STANDALONE.html"
