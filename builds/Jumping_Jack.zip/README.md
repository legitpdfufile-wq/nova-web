# Jumping Jack

Open PLAY_STANDALONE.html directly; it contains the entire game. No server, install, account or internet needed.

Arrow Left/Right or A/D move. Space jumps. Escape pauses/resumes. Reach the final beacon to win; falling loses. Play again or Restart run resets everything.

index.html, styles.css and game.js are the editable source version; keep them together.

Construction: Studio local-model level design and a reusable Studio physics/rendering/UI engine. No claim that every line was model-written.
