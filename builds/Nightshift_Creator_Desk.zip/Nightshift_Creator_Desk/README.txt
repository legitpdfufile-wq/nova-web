STUDIO BRAIN PRODUCT
Open index.html or START_PRODUCT.bat.
Runs offline in Edge/Chrome. Browser data belongs to this browser profile.
No server, payment, email delivery or public hosting is implied.
Release checks: actual UI actions, exact requirement tests, desktop/mobile-width layouts.
Not physical-device certification or a guarantee of every untested requirement.
Delivery mode: final
