@echo off
start "" "%~dp0runtime\pythonw.exe" "%~dp0app\launch.py" --stop
