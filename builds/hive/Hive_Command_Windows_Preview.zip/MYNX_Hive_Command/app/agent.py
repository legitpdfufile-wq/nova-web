"""Device worker: telemetry, inventory, metadata watching and explicit commands."""
import argparse
import ctypes
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import platform
import shutil
import socket
import sqlite3
import stat
import subprocess
import threading
import time
from urllib.parse import urlparse
from urllib.request import Request, urlopen


def process(args, timeout=25):
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                          creationflags=0x08000000 if os.name == 'nt' else 0)


def linked_path(path, attrs):
    # Cloud placeholders may be reparse points too; indexing their metadata
    # must not silently exclude the owner's entire OneDrive desktop.
    return path.is_symlink() or getattr(attrs,'st_reparse_tag',0) in (0xA0000003,0xA000000C)


class Agent:
    def __init__(self, root, relay, device, key):
        self.root = Path(root)
        self.relay = relay.rstrip('/')
        self.device = device
        self.key = key
        self.stop = threading.Event()
        self.snapshot_path = self.root/'data'/'watch.sqlite3'
        self.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        self.scan_lock = threading.Lock()
        self.command_lock = threading.Lock()
        self.inventory_lock = threading.Lock()
        self.inventory_signature = None
        self.last_scan = {'status': 'not configured'}
        self.cpu_previous = None
        self.log = logging.getLogger('hive.agent.'+device+'.'+hashlib.sha256(str(self.root).encode()).hexdigest()[:12])
        if not self.log.handlers:
            handler = RotatingFileHandler(self.root/'data'/'agent.log', maxBytes=512000, backupCount=3, encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.log.addHandler(handler)
            self.log.setLevel(logging.INFO)

    def api(self, path, body=None):
        request = Request(self.relay+path, data=json.dumps(dict(body, device_id=self.device)).encode() if body is not None else None,
                          headers={'Authorization':'Bearer '+self.key, 'Content-Type':'application/json'})
        with urlopen(request, timeout=10) as response:
            return json.load(response)

    def health(self):
        out = {'device_id': self.device, 'os': platform.system(), 'timestamp': time.time(),
               'disk': [], 'watch': self.last_scan}
        if os.name == 'nt':
            class Memory(ctypes.Structure):
                _fields_ = [('length',ctypes.c_ulong),('load',ctypes.c_ulong),('total',ctypes.c_ulonglong),
                            ('available',ctypes.c_ulonglong),('page_total',ctypes.c_ulonglong),('page_available',ctypes.c_ulonglong),
                            ('virtual_total',ctypes.c_ulonglong),('virtual_available',ctypes.c_ulonglong),('extended',ctypes.c_ulonglong)]
            mem=Memory(); mem.length=ctypes.sizeof(mem)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem)):
                out.update(ram_percent=mem.load,ram_total=mem.total,ram_available=mem.available)
            idle=ctypes.c_ulonglong(); kernel=ctypes.c_ulonglong(); user=ctypes.c_ulonglong()
            if ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):
                current=(idle.value,kernel.value+user.value)
                if self.cpu_previous:
                    delta=current[1]-self.cpu_previous[1]
                    out['cpu_percent']=round(100*(1-(current[0]-self.cpu_previous[0])/delta),1) if delta>0 else None
                self.cpu_previous=current
            ctypes.windll.kernel32.GetTickCount64.restype=ctypes.c_ulonglong
            out['uptime_seconds']=ctypes.windll.kernel32.GetTickCount64()/1000
            roots=[str(Path(self.root).anchor)]
            mask=ctypes.windll.kernel32.GetLogicalDrives()
            roots=[chr(65+i)+':\\' for i in range(26) if mask&(1<<i)] or roots
        else:
            roots=['/']
        for root in roots:
            try:
                total,used,free=shutil.disk_usage(root)
                out['disk'].append({'path':root,'total':total,'free':free,'percent':round(100*used/total,1)})
            except OSError:
                pass
        return out

    def inventory(self):
        out={'hostname':socket.gethostname(),'os':platform.platform(),'architecture':platform.machine(),'devices':[]}
        if os.name == 'nt':
            script="Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object {$_.Class -in @('USB','Bluetooth','HIDClass','Ports','Camera','Image','DiskDrive')} | Select-Object Class,FriendlyName,InstanceId,Status | ConvertTo-Json -Depth 3 -Compress"
            result=process(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],40)
            if not result.returncode:
                data=json.loads(result.stdout.lstrip('\ufeff') or '[]')
                out['devices']=data if isinstance(data,list) else [data]
                out['source']='Windows present-device query'
                out['presence_verified']=True
            else:
                out['present_device_query_error']=result.stderr[:500]
                out['source']='Readable Windows device registry; historical records may be included'
                out['presence_verified']=False
                import winreg
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SYSTEM\CurrentControlSet\Enum') as enum:
                    for i in range(winreg.QueryInfoKey(enum)[0]):
                        bus=winreg.EnumKey(enum,i)
                        try:
                            with winreg.OpenKey(enum,bus) as buskey:
                                for j in range(winreg.QueryInfoKey(buskey)[0]):
                                    model=winreg.EnumKey(buskey,j)
                                    with winreg.OpenKey(buskey,model) as modelkey:
                                        for k in range(winreg.QueryInfoKey(modelkey)[0]):
                                            instance=winreg.EnumKey(modelkey,k)
                                            try:
                                                with winreg.OpenKey(modelkey,instance) as inst:
                                                    def value(name):
                                                        try:return winreg.QueryValueEx(inst,name)[0]
                                                        except OSError:return None
                                                    kind=value('Class')
                                                    if not kind:
                                                        guid=value('ClassGUID')
                                                        if guid:
                                                            try:
                                                                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,'SYSTEM\\CurrentControlSet\\Control\\Class\\'+guid) as classkey:
                                                                    kind=winreg.QueryValueEx(classkey,'Class')[0]
                                                            except OSError:pass
                                                    if kind in ('USB','Bluetooth','HIDClass','Ports','Camera','Image','DiskDrive'):
                                                        out['devices'].append({'Class':kind,'FriendlyName':value('FriendlyName') or value('DeviceDesc'),'InstanceId':bus+'\\'+model+'\\'+instance,'Status':'Presence not verified'})
                                            except OSError:continue
                        except OSError:continue
                if not out['devices']:
                    raise RuntimeError('Windows denied present-device inventory and no eligible device records were readable. No elevation attempted.')
        signature=hashlib.sha256(json.dumps(out,sort_keys=True).encode()).hexdigest()
        if signature!=self.inventory_signature:
            self.api('/usb/event',{'event':'inventory','inventory':out})
            self.inventory_signature=signature
        return {'hardware_devices':len(out['devices']),'inventory':out}

    def android(self):
        adb=shutil.which('adb')
        if not adb:
            raise RuntimeError('Android Platform Tools / adb is not installed. No download attempted.')
        listing=process([adb,'devices'],15)
        if listing.returncode:
            raise RuntimeError('ADB inventory failed.')
        phones=[]
        for line in listing.stdout.splitlines()[1:]:
            columns=line.split()
            if len(columns)==2 and columns[1]=='device':
                result=process([adb,'-s',columns[0],'shell','df','/sdcard'],15)
                phones.append({'serial':columns[0],'storage_report':result.stdout,'read_ok':result.returncode==0})
        self.api('/phone/storage',{'phones':phones, 'meaning':'USB-authorized Android devices connected to this reporting computer.'})
        return {'phones':phones}

    def scan(self):
        if not self.scan_lock.acquire(blocking=False):
            return {'status':'scan already running'}
        try:
            cfg=self.api('/agent/settings')
            roots=cfg.get('watch_roots',[])
            excluded=[os.path.normcase(os.path.abspath(p)) for p in cfg.get('exclusions',[])]
            if not roots:
                self.last_scan={'status':'not configured','paths':0}
                return self.last_scan
            db=sqlite3.connect(self.snapshot_path)
            db.execute('CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY,signature TEXT NOT NULL)')
            counts={'observed':0,'new':0,'changed':0,'missing':0,'errors':0,'skipped_links':0,'partial':False}
            batch=[]; observed=set(); errors=[]
            def ignored(path):
                normalized=os.path.normcase(os.path.abspath(path))
                return any(normalized==x or normalized.startswith(x+os.sep) for x in excluded)
            def send():
                if batch:
                    self.api('/links/batch',{'links':list(batch)})
                    batch.clear()
            def walk_error(exc):
                counts['errors']+=1
                errors.append(str(exc)[:300])
            complete=True
            for root_text in roots:
                root=Path(root_text)
                if not root.is_dir() or ignored(root) or root.resolve().is_relative_to((self.root/'data').resolve()):
                    errors.append('Unavailable or excluded root: '+str(root));counts['errors']+=1;complete=False
                    continue
                for folder,dirs,files in os.walk(root,followlinks=False,onerror=walk_error):
                    kept=[]
                    for name in dirs:
                        p=Path(folder)/name
                        try:
                            attrs=p.lstat()
                            is_link=linked_path(p,attrs)
                            if is_link:
                                counts['skipped_links']+=1
                            elif name not in ('MEDIEVAL_AI_VAULT_V1','.git','__pycache__') and not ignored(p) and not p.resolve().is_relative_to((self.root/'data').resolve()):
                                kept.append(name)
                        except OSError as exc:
                            walk_error(exc)
                    dirs[:]=kept
                    for name in files:
                        p=Path(folder)/name
                        if ignored(p):continue
                        try:
                            attrs=p.lstat()
                            if not stat.S_ISREG(attrs.st_mode) or linked_path(p,attrs):
                                counts['skipped_links']+=1;continue
                            key=os.path.normcase(os.path.abspath(p))
                            observed.add(key)
                            signature=json.dumps([attrs.st_size,attrs.st_mtime_ns,attrs.st_ino])
                            old=db.execute('SELECT signature FROM files WHERE path=?',(key,)).fetchone()
                            event='observed' if not old else 'changed' if old[0]!=signature else None
                            counts['observed']+=1
                            if event:
                                counts['new' if not old else 'changed']+=1
                                batch.append({'path':str(p),'event':event,'size':attrs.st_size,'modified_ns':attrs.st_mtime_ns,'file_id':str(attrs.st_ino)})
                                if len(batch)>=100:send()
                                db.execute('INSERT OR REPLACE INTO files VALUES(?,?)',(key,signature))
                            if counts['observed']>=100000:
                                counts['partial']=True;complete=False;break
                        except OSError as exc:walk_error(exc)
                    if not complete:break
                if not complete:break
            # An unavailable subtree cannot be treated as deleted files.
            if complete and counts['errors']==0:
                normalized_roots=[os.path.normcase(os.path.abspath(p)) for p in roots]
                for (path,) in db.execute('SELECT path FROM files').fetchall():
                    selected=any(path.startswith(r.rstrip(os.sep)+os.sep) for r in normalized_roots)
                    if selected and path not in observed and not ignored(path):
                        counts['missing']+=1
                        batch.append({'path':path,'event':'missing','meaning':'No deletion performed by Hive.'})
                        if len(batch)>=100:send()
                        db.execute('DELETE FROM files WHERE path=?',(path,))
            send();db.commit();db.close()
            self.last_scan={'status':'partial' if counts['partial'] or counts['errors'] else 'complete',**counts,'errors_detail':errors[:10],'at':time.time()}
            return self.last_scan
        finally:
            self.scan_lock.release()

    def execute(self, command):
        action=command['action']; args=command['args']
        if action=='inventory':return self.inventory()
        if action=='android_inventory':return self.android()
        if action=='scan_now':return self.scan()
        if action=='cleanup_temp':
            # Preview only. The original source's unbounded delete is retained in the archive,
            # never silently re-enabled on someone's working computer.
            root=Path(os.getenv('TEMP') or os.getenv('TMP') or '/tmp')
            candidates=[]
            for p in root.iterdir():
                try:
                    attrs=p.lstat()
                    if p.is_file() and not p.is_symlink() and not (getattr(attrs,'st_file_attributes',0)&0x400) and attrs.st_mtime<time.time()-7*86400:
                        candidates.append({'path':str(p),'bytes':attrs.st_size})
                        if len(candidates)>=1000:break
                except OSError:pass
            return {'mode':'preview_only','files':candidates,'originals_changed':0,'note':'No cleanup deletion is enabled in this owner-test release.'}
        if action=='reboot':
            if os.name!='nt':raise RuntimeError('Windows reboot only.')
            consent=ctypes.windll.user32.MessageBoxW(None,'MYNX Hive Command received a reboot request. Restart THIS computer in 60 seconds? Save your work first. You can cancel with shutdown /a.','Hive — local approval required',0x104)
            if consent!=6:return {'declined':True,'restarted':False}
            result=process(['shutdown.exe','/r','/t','60','/c','MYNX Hive Command: owner approved restart.'])
            if result.returncode:raise RuntimeError(result.stderr[:300])
            return {'scheduled_in_seconds':60,'cancel':'shutdown /a'}
        if action=='open_camera':
            url=args.get('url','')
            parsed=urlparse(url)
            if parsed.scheme not in ('rtsp','http','https') or not parsed.hostname or any(c in url for c in '\r\n\x00'):
                raise ValueError('Provide an actual RTSP/HTTP camera address.')
            vlc=shutil.which('vlc')
            if not vlc:
                for p in [Path(os.environ.get('ProgramFiles','C:/Program Files'))/'VideoLAN/VLC/vlc.exe',Path('C:/Program Files (x86)/VideoLAN/VLC/vlc.exe')]:
                    if p.is_file():vlc=str(p);break
            if not vlc:raise RuntimeError('VLC is not available on this device. No installation attempted.')
            if os.name=='nt' and ctypes.windll.user32.MessageBoxW(None,'Open the requested camera stream in VLC on THIS device?','Hive — camera request',0x104)!=6:
                return {'declined':True}
            subprocess.Popen([vlc,'--',url],creationflags=0x08000000 if os.name=='nt' else 0)
            return {'player_started':True,'video_verified':False}
        raise ValueError('Unsupported command.')

    def run(self):
        registered=False;last_beat=0;last_health=0;last_scan=0;last_inventory=0
        while not self.stop.is_set():
            try:
                if not registered:
                    self.api('/register/device',{'hostname':socket.gethostname(),'type':'computer','os':platform.system(),'version':platform.version(),'architecture':platform.machine()})
                    registered=True
                now=time.monotonic()
                if now-last_beat>=10:self.api('/heartbeat',{});last_beat=now
                if now-last_health>=10:self.api('/device/health',self.health());last_health=now
                if now-last_scan>=30:
                    if not self.scan_lock.locked():threading.Thread(target=self.scan_guarded,daemon=True).start()
                    last_scan=now
                if now-last_inventory>=60:
                    if self.inventory_lock.acquire(blocking=False):
                        threading.Thread(target=self.inventory_guarded,daemon=True).start()
                    last_inventory=now
                if self.command_lock.acquire(blocking=False):
                    try:
                        commands=self.api('/device/commands').get('commands',[])
                        if commands:
                            threading.Thread(target=self.command_guarded,args=(commands[0],),daemon=True).start()
                        else:self.command_lock.release()
                    except Exception:
                        self.command_lock.release()
                        raise
            except Exception as exc:
                self.log.warning('%s',str(exc)[:500]);registered=False
            self.stop.wait(2)

    def scan_guarded(self):
        try:self.scan()
        except Exception as exc:
            self.last_scan={'status':'failed','error':str(exc)[:400]}
            self.log.warning('Watch scan failed: %s',str(exc)[:400])

    def inventory_guarded(self):
        try:self.inventory()
        except Exception as exc:self.log.warning('Hardware inventory failed: %s',str(exc)[:400])
        finally:self.inventory_lock.release()

    def command_guarded(self, command):
        try:self._command_guarded(command)
        finally:self.command_lock.release()

    def _command_guarded(self, command):
        try:
            result=self.execute(command)
            status='declined' if result.get('declined') else 'completed'
        except Exception as exc:
            result={'error':str(exc)[:500]};status='failed'
        # Do not rerun a side effect if result delivery fails.
        for attempt in range(3):
            try:
                self.api('/command/result',{'id':command['id'],'status':status,'result':result})
                return
            except Exception as exc:
                self.log.warning('Result delivery failed for %s: %s',command['id'],str(exc)[:300])
                self.stop.wait(2)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',required=True)
    args=parser.parse_args()
    cfg_path=Path(args.config).resolve()
    cfg=json.loads(cfg_path.read_text(encoding='utf-8-sig'))
    if urlparse(cfg['relay']).scheme!='http' or not urlparse(cfg['relay']).hostname:
        raise ValueError('A valid private relay URL is required.')
    agent=Agent(cfg_path.parent,cfg['relay'],cfg['device_id'],cfg['key'])
    try:agent.run()
    except KeyboardInterrupt:agent.stop.set()
