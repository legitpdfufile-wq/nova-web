"""MYNX Hive Command: owner-controlled relay. Standard library only."""
import argparse
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
MAX_BODY = 1024 * 1024
VERSION = '1.0-owner-test'


class Hive:
    def __init__(self, root=ROOT, port=8957):
        self.root = Path(root)
        self.data = self.root / 'data'
        self.data.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.secrets_path = self.data / 'access.json'
        if self.secrets_path.exists():
            self.keys = json.loads(self.secrets_path.read_text(encoding='utf-8'))
        else:
            self.keys = {'owner': secrets.token_urlsafe(36), 'agents': {}}
            self.save_keys()
        self.db = sqlite3.connect(self.data / 'hive.sqlite3', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA busy_timeout=5000')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, body TEXT NOT NULL, seen REAL NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS health(device TEXT PRIMARY KEY, body TEXT NOT NULL, stamp REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS cameras(id TEXT PRIMARY KEY, device TEXT NOT NULL, body TEXT NOT NULL, stamp REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS links(device TEXT NOT NULL,path TEXT NOT NULL,body TEXT NOT NULL,stamp REAL NOT NULL,PRIMARY KEY(device,path));
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,stamp REAL NOT NULL,device TEXT,kind TEXT NOT NULL,body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS commands(id TEXT PRIMARY KEY,device TEXT NOT NULL,action TEXT NOT NULL,args TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,result TEXT);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        ''')
        self.db.commit()
        self.db.execute("UPDATE commands SET status='outcome_unknown',updated=? WHERE status='claimed'", (time.time(),))
        self.db.commit()
        self.port = port

    def save_keys(self):
        temp = self.secrets_path.with_suffix('.tmp')
        temp.write_text(json.dumps(self.keys, indent=2), encoding='utf-8')
        temp.replace(self.secrets_path)

    def agent_key(self, device):
        with self.lock:
            if device not in self.keys['agents']:
                self.keys['agents'][device] = secrets.token_urlsafe(36)
                self.save_keys()
            return self.keys['agents'][device]

    def identity(self, token):
        with self.lock:
            if token and hmac.compare_digest(token, self.keys['owner']):
                return 'owner', None
            for device, key in self.keys['agents'].items():
                if token and hmac.compare_digest(token, key):
                    return 'agent', device
        return None, None

    def event(self, device, kind, body):
        self.db.execute('INSERT INTO events(stamp,device,kind,body) VALUES(?,?,?,?)',
                        (time.time(), device, kind, json.dumps(body)))

    def rows(self, sql, params=()):
        return [dict(r) for r in self.db.execute(sql, params)]

    def settings(self):
        return {r['key']: json.loads(r['value']) for r in self.db.execute('SELECT * FROM settings')}

    def devices(self):
        return [{**json.loads(r['body']), 'device_id': r['id'], 'last_seen': r['seen'],
                 'online': time.time() - r['seen'] < 35}
                for r in self.db.execute('SELECT * FROM devices ORDER BY id')]

    def dispatch(self, method, path, body, role, identity):
        """All mutation, validation and transactions pass through this function."""
        with self.lock:
            try:
                result = self._dispatch(method, path, body, role, identity)
                self.db.commit()
                return result
            except Exception:
                self.db.rollback()
                raise

    def _dispatch(self, method, path, b, role, identity):
        owner = role == 'owner'
        device = b.get('device_id') or identity
        if not owner and device != identity:
            raise PermissionError('This key belongs to a different device.')
        if method == 'GET':
            if path == '/health':
                return {'status': 'ok', 'product': 'MYNX Hive Command', 'version': VERSION}
            if path == '/device/commands':
                if role != 'agent':
                    raise PermissionError('Agent key required.')
                now = time.time()
                self.db.execute("UPDATE commands SET status='expired',updated=? WHERE status='queued' AND created<?", (now, now-900))
                rows = self.rows("SELECT * FROM commands WHERE device=? AND status='queued' ORDER BY created LIMIT 1", (identity,))
                for row in rows:
                    self.db.execute("UPDATE commands SET status='claimed',updated=? WHERE id=?", (now, row['id']))
                    row['args'] = json.loads(row['args'])
                return {'commands': rows}
            if path == '/agent/settings':
                if role != 'agent':
                    raise PermissionError('Agent key required.')
                return self.settings().get('agent:' + identity, {'watch_roots': [], 'exclusions': []})
            if not owner:
                raise PermissionError('Owner access required.')
            if path in ('/devices', '/devices/status'):
                return {'devices': self.devices()}
            if path == '/cameras':
                return {'cameras': [{**r, 'body': json.loads(r['body'])} for r in self.rows('SELECT * FROM cameras')]}
            if path == '/links':
                return {'links': [{**r, 'body': json.loads(r['body'])} for r in self.rows('SELECT * FROM links ORDER BY stamp DESC LIMIT 2000')]}
            if path in ('/dashboard', '/api/snapshot'):
                return {'product': 'MYNX Hive Command', 'version': VERSION, 'devices': self.devices(),
                        'health': [{**r, 'body': json.loads(r['body'])} for r in self.rows('SELECT * FROM health')],
                        'cameras': [{**r, 'body': json.loads(r['body'])} for r in self.rows('SELECT * FROM cameras')],
                        'links': self.rows('SELECT device,path,stamp FROM links ORDER BY stamp DESC LIMIT 200'),
                        'link_count': self.db.execute('SELECT COUNT(*) FROM links').fetchone()[0],
                        'events': [{**r, 'body': json.loads(r['body'])} for r in self.rows('SELECT * FROM events ORDER BY id DESC LIMIT 100')],
                        'commands': [{**r, 'args': json.loads(r['args']), 'result': json.loads(r['result']) if r['result'] else None}
                                     for r in self.rows('SELECT * FROM commands ORDER BY created DESC LIMIT 100')],
                        'settings': self.settings()}
            if path == '/relays':
                return {'relays': self.settings().get('verified_relays', []),
                        'note': 'No background subnet scans. Pair devices explicitly; no workload distribution is implied.'}
            raise LookupError('Endpoint not found.')

        if method != 'POST':
            raise ValueError('Unsupported method.')
        if path == '/api/pair':
            if not owner:
                raise PermissionError('Owner access required.')
            target = required(b, 'device_id', 120)
            key = self.agent_key(target)
            self.event(None, 'device_key_created', {'device_id': target})
            return {'device_id': target, 'key': key, 'warning': 'Private device credential. Do not publish.'}
        if path == '/api/revoke':
            if not owner:
                raise PermissionError('Owner access required.')
            target = required(b, 'device_id', 120)
            self.keys['agents'].pop(target, None)
            self.save_keys()
            self.db.execute('UPDATE devices SET seen=0 WHERE id=?', (target,))
            self.event(target, 'device_access_revoked', {})
            return {'revoked': True, 'history_retained': True}
        if path == '/api/settings':
            if not owner:
                raise PermissionError('Owner access required.')
            target = required(b, 'device_id', 120)
            roots = b.get('watch_roots', [])
            exclusions = b.get('exclusions', [])
            if not isinstance(roots, list) or len(roots) > 12 or not all(isinstance(x, str) and len(x)<4096 for x in roots):
                raise ValueError('Provide up to twelve folder paths.')
            if not isinstance(exclusions, list) or not all(isinstance(x, str) for x in exclusions):
                raise ValueError('Exclusions must be a list of folder paths.')
            settings = {'watch_roots': roots, 'exclusions': exclusions}
            self.db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)', ('agent:'+target, json.dumps(settings)))
            self.event(target, 'watch_configuration', settings)
            return {'saved': True}
        if path == '/api/command':
            if not owner:
                raise PermissionError('Owner access required.')
            target = required(b, 'device_id', 120)
            action = required(b, 'action', 80)
            if action not in ('inventory', 'android_inventory', 'scan_now', 'open_camera', 'cleanup_temp', 'reboot'):
                raise ValueError('Unknown action.')
            if not self.db.execute('SELECT 1 FROM devices WHERE id=?', (target,)).fetchone():
                raise ValueError('Register the device first.')
            args = b.get('args', {})
            if not isinstance(args, dict):
                raise ValueError('Arguments must be an object.')
            if action in ('cleanup_temp', 'reboot') and b.get('confirmation') != action + ':' + target:
                raise ValueError('This action requires the exact action:device confirmation.')
            if action == 'cleanup_temp':
                args = {'minimum_age_days': 7, 'maximum_files': 1000}
            command_id = secrets.token_hex(12)
            now = time.time()
            self.db.execute('INSERT INTO commands VALUES(?,?,?,?,?,?,?,?)',
                            (command_id, target, action, json.dumps(args), 'queued', now, now, None))
            self.event(target, 'command_queued', {'id': command_id, 'action': action})
            return {'id': command_id, 'status': 'queued'}
        if path == '/command/result':
            if role != 'agent':
                raise PermissionError('Agent key required.')
            row = self.db.execute('SELECT * FROM commands WHERE id=?', (required(b, 'id', 80),)).fetchone()
            if not row or row['device'] != identity:
                raise PermissionError('Command does not belong to this device.')
            if row['status'] not in ('claimed', 'outcome_unknown'):
                raise ValueError('Command is not awaiting a result.')
            status = b.get('status')
            if status not in ('completed', 'failed', 'declined'):
                raise ValueError('Invalid result status.')
            self.db.execute('UPDATE commands SET status=?,result=?,updated=? WHERE id=?',
                            (status, json.dumps(b.get('result')), time.time(), row['id']))
            self.event(identity, 'command_result', {'id': row['id'], 'status': status})
            return {'saved': True}
        if not device or not isinstance(device, str) or len(device)>120:
            raise ValueError('A valid device_id is required.')
        if path in ('/register/device', '/register/phone'):
            payload = dict(b, device_id=device)
            previous = self.db.execute('SELECT seen FROM devices WHERE id=?', (device,)).fetchone()
            self.db.execute('INSERT OR REPLACE INTO devices VALUES(?,?,?)',
                            (device, json.dumps(payload), previous['seen'] if previous else 0))
            self.event(device, 'registered', {'type': payload.get('type')})
            return {'status': 'registered'}
        if path == '/heartbeat':
            if not self.db.execute('SELECT 1 FROM devices WHERE id=?', (device,)).fetchone():
                raise ValueError('Register before sending a heartbeat.')
            self.db.execute('UPDATE devices SET seen=? WHERE id=?', (time.time(), device))
            return {'status': 'ok'}
        if path == '/phone/storage':
            self.event(device, 'android_storage', b)
            return {'saved': True}
        if path == '/device/health':
            self.db.execute('INSERT OR REPLACE INTO health VALUES(?,?,?)', (device, json.dumps(b), time.time()))
            return {'saved': True}
        if path == '/usb/event':
            self.event(device, 'hardware_change', b)
            return {'saved': True}
        if path in ('/register/dvr_camera', '/register/cameras'):
            cameras = b.get('cameras', [b])
            if not isinstance(cameras, list) or len(cameras)>100:
                raise ValueError('Invalid camera list.')
            for camera in cameras:
                if not isinstance(camera, dict):
                    raise ValueError('Invalid camera.')
                cid = required(camera, 'camera_id', 120)
                self.db.execute('INSERT OR REPLACE INTO cameras VALUES(?,?,?,?)',
                                (device+':'+cid, device, json.dumps(camera), time.time()))
            self.event(device, 'camera_registration', {'count': len(cameras)})
            return {'registered': len(cameras)}
        if path == '/cameras/heartbeat':
            ids = b.get('camera_ids', [])
            if not isinstance(ids, list) or not all(isinstance(cid,str) for cid in ids):
                raise ValueError('camera_ids must be strings.')
            for cid in ids:
                self.db.execute('UPDATE cameras SET stamp=? WHERE id=? AND device=?', (time.time(), device+':'+cid, device))
            return {'saved': True, 'meaning': 'Reporter contact, not verified video availability.'}
        if path == '/links/batch':
            links = b.get('links')
            if not isinstance(links, list) or not 1 <= len(links) <= 500:
                raise ValueError('Provide one to five hundred path records.')
            for record in links:
                if not isinstance(record, dict):
                    raise ValueError('Invalid path record.')
                path_value = required(record, 'path', 4096)
                self.db.execute('INSERT OR REPLACE INTO links VALUES(?,?,?,?)',
                                (device, path_value, json.dumps(record), time.time()))
            self.event(device, 'path_batch', {'count': len(links), 'events': {kind: sum(r.get('event')==kind for r in links) for kind in ('observed','changed','missing')}})
            return {'saved': len(links)}
        if path == '/link':
            path_value = required(b, 'path', 4096)
            self.db.execute('INSERT OR REPLACE INTO links VALUES(?,?,?,?)',
                            (device, path_value, json.dumps(b), time.time()))
            self.event(device, 'path_'+str(b.get('event', 'observed'))[:40], {'path': path_value})
            return {'status': 'linked', 'meaning': 'Indexed reference; original unchanged.'}
        raise LookupError('Endpoint not found.')


def required(b, key, maximum):
    value = b.get(key)
    if not isinstance(value, str) or not value.strip() or len(value)>maximum:
        raise ValueError('Invalid '+key)
    return value.strip()


def handler_for(hive):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'MYNXHiveCommand/1.0'
        def log_message(self, *_):
            pass  # no credentials, request bodies or query strings in console logs

        def send(self, status, value, content_type='application/json; charset=utf-8'):
            data = value if isinstance(value, bytes) else json.dumps(value).encode()
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
            self.end_headers()
            self.wfile.write(data)

        def do_OPTIONS(self):
            self.send(403, {'error': 'Cross-origin access disabled.'})

        def request(self):
            self.connection.settimeout(8)
            path = urlparse(self.path).path.rstrip('/') or '/'
            if self.command == 'GET' and path == '/identity':
                return self.send(200, {'product':'MYNX Hive Command', 'instance':hashlib.sha256(str(hive.root.resolve()).encode()).hexdigest(), 'lan':self.server.server_address[0]=='0.0.0.0'})
            if self.command == 'GET' and path in ('/', '/dashboard-ui', '/app.js', '/style.css'):
                name = {'/':'dashboard.html', '/dashboard-ui':'dashboard.html', '/app.js':'app.js', '/style.css':'style.css'}[path]
                mime = 'text/html' if name.endswith('html') else 'text/javascript' if name.endswith('js') else 'text/css'
                return self.send(200, (Path(__file__).parent/name).read_bytes(), mime+'; charset=utf-8')
            auth = self.headers.get('Authorization','')
            role, identity = hive.identity(auth[7:] if auth.startswith('Bearer ') else '')
            if not role:
                return self.send(401, {'error': 'Private Hive access key required.'})
            origin = self.headers.get('Origin')
            if origin and origin != 'http://'+self.headers.get('Host',''):
                return self.send(403, {'error': 'Cross-origin request refused.'})
            try:
                body = {}
                if self.command == 'POST':
                    if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
                        return self.send(415, {'error': 'Use application/json.'})
                    size = int(self.headers.get('Content-Length','0'))
                    if size<=0 or size>MAX_BODY:
                        return self.send(413, {'error': 'Request body must be 1 byte to 1 MiB.'})
                    body = json.loads(self.rfile.read(size))
                    if not isinstance(body, dict):
                        raise ValueError('A JSON object is required.')
                if self.command == 'POST' and path == '/api/stop':
                    if role != 'owner':
                        return self.send(403, {'error':'Owner access required.'})
                    self.send(200, {'stopping':True})
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                    return
                self.send(200, hive.dispatch(self.command, path, body, role, identity))
            except PermissionError as exc:
                self.send(403, {'error': str(exc)})
            except LookupError as exc:
                self.send(404, {'error': str(exc)})
            except (ValueError, TypeError) as exc:
                self.send(400, {'error': str(exc)})
            except Exception:
                self.send(500, {'error': 'Request failed. Data transaction was rolled back.'})

        do_GET = request
        do_POST = request
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8957)
    parser.add_argument('--lan', action='store_true')
    args = parser.parse_args()
    hive = Hive(port=args.port)
    server = ThreadingHTTPServer(('0.0.0.0' if args.lan else '127.0.0.1', args.port), handler_for(hive))
    server.daemon_threads = True
    from agent import Agent
    import socket
    device = socket.gethostname()
    local_agent = Agent(ROOT, 'http://127.0.0.1:'+str(server.server_port), device, hive.agent_key(device))
    threading.Thread(target=local_agent.run, daemon=True).start()
    try:
        server.serve_forever()
    finally:
        local_agent.stop.set()
        server.server_close()
        hive.db.close()


if __name__ == '__main__':
    main()
