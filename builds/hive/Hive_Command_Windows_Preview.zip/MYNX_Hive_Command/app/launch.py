"""Start only this Hive instance; never terminate another program to free a port."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from urllib.request import Request, urlopen
from urllib.error import URLError
import webbrowser

ROOT=Path(__file__).resolve().parent.parent
URL='http://127.0.0.1:8957'

def message(text):
    if os.name=='nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,text,'MYNX Hive Command',0x40)
    else:print(text)

def identity():
    try:
        with urlopen(URL+'/identity',timeout=2) as response:return json.load(response)
    except URLError:return None

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stop',action='store_true')
    parser.add_argument('--lan',action='store_true')
    args=parser.parse_args()
    instance=hashlib.sha256(str(ROOT.resolve()).encode()).hexdigest()
    current=identity()
    if current and current.get('instance')!=instance:
        raise RuntimeError('Port 8957 belongs to a different instance. Nothing was stopped or replaced.')
    if args.stop:
        if not current:return message('This Hive instance is not running.')
        access=json.loads((ROOT/'data'/'access.json').read_text(encoding='utf-8'))
        req=Request(URL+'/api/stop',data=b'{}',headers={'Authorization':'Bearer '+access['owner'],'Content-Type':'application/json'})
        with urlopen(req,timeout=5):pass
        return
    if args.lan and current and not current.get('lan'):
        return message('Hive is already running in private local mode. Use STOP HIVE COMMAND, then START HIVE LAN. No other service will be stopped.')
    if not current:
        if args.lan and os.name=='nt':
            import ctypes
            if ctypes.windll.user32.MessageBoxW(None,'Enable Hive on your private LAN? This edition uses authenticated HTTP, not encrypted HTTPS. Do not expose it to the internet or an untrusted network. Windows may ask about its firewall.','Hive — optional LAN access',0x104)!=6:return
        (ROOT/'data').mkdir(exist_ok=True)
        runtime=ROOT/'runtime'/'python.exe'
        log=(ROOT/'data'/'service.log').open('a',encoding='utf-8')
        command=[str(runtime),str(ROOT/'app'/'service.py')]+(['--lan'] if args.lan else [])
        subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=log,creationflags=0x08000000 if os.name=='nt' else 0)
        log.close()
        for _ in range(60):
            current=identity()
            if current and current.get('instance')==instance:break
            time.sleep(.25)
        else:raise RuntimeError('Hive did not become ready. See data/service.log. No process was killed.')
    access=json.loads((ROOT/'data'/'access.json').read_text(encoding='utf-8'))
    webbrowser.open(URL+'/#key='+access['owner'])

if __name__=='__main__':
    try:main()
    except Exception as exc:message(str(exc))
