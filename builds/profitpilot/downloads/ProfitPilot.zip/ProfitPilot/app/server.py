"""ProfitPilot local launcher and same-origin Ollama bridge. No cloud AI service."""
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json, secrets, threading, sys, webbrowser, os

ROOT = Path(__file__).resolve().parent
TOKEN = secrets.token_urlsafe(32)
BUSY = threading.Lock()
FILE_LOCK = threading.Lock()
WORKSPACE = ROOT / 'PRIVATE_WORKSPACE.json'
OLLAMA = 'http://127.0.0.1:11434'
BUSINESS = (ROOT / 'business-system.txt').read_text(encoding='utf-8')
CAREER = '''You are ProfitPilot, a practical career and job-search coach. Use the supplied profile and conversation history. Help users identify career directions, prepare truthful applications, evaluate pasted vacancies, and plan concrete next steps. Ask one useful question at a time when facts are missing. Never invent current vacancies, employers hiring, salaries, qualifications, experience or hiring guarantees. The app offers a sourced Jobicy remote feed and job-board links, but you cannot browse independently: use only actual posting text the user provides when evaluating an opening. Distinguish career suggestions from confirmed jobs. If the profile indicates under 18, avoid hazardous, adult-only or age-restricted work; tell them to check the employer's age requirement with a parent/guardian, without inventing legal eligibility. Do not ask for a home address, date of birth, ID numbers or account credentials. Do not submit applications or contact employers. Be concise, encouraging and honest. Do not default career seekers to business hustles or sales outreach.'''

def call(route, data=None, timeout=8):
    req = Request(OLLAMA + route, data=json.dumps(data).encode() if data is not None else None,
                  headers={'Content-Type': 'application/json'})
    with urlopen(req, timeout=timeout) as r:
        return json.load(r)

class Handler(BaseHTTPRequestHandler):
    def reply(self, value, code=200):
        body = json.dumps(value).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def trusted(self):
        origin = self.headers.get('Origin')
        return self.headers.get('Host') == self.server.host and (not origin or origin == 'http://' + self.server.host)

    def do_GET(self):
        if not self.trusted(): return self.reply({'error': 'Local requests only.'}, 403)
        if self.path == '/api/workspace':
            try:
                with FILE_LOCK:
                    data = json.loads(WORKSPACE.read_text(encoding='utf-8')) if WORKSPACE.exists() else None
                return self.reply({'workspace': data})
            except Exception:
                return self.reply({'error': 'The private workspace file could not be read. It has not been replaced; export a browser backup and inspect PRIVATE_WORKSPACE.json.'}, 500)
        if self.path == '/api/setup':
            try:
                models = [r['name'] for r in call('/api/tags')['models']]
                models = [m for m in models if 'embed' not in m.lower()]
                self.reply({'local': True, 'token': TOKEN, 'models': models, 'ollama': True})
            except Exception:
                self.reply({'local': True, 'token': TOKEN, 'models': [], 'ollama': False})
            return
        import mimetypes
        rel = self.path.split('?', 1)[0].lstrip('/') or 'index.html'
        p = (ROOT / 'web' / rel).resolve()
        if not p.is_relative_to((ROOT / 'web').resolve()) or not p.is_file(): return self.reply({'error': 'Not found'}, 404)
        data = p.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if not self.trusted() or self.headers.get('X-ProfitPilot-Token') != TOKEN:
            return self.reply({'error': 'Reopen ProfitPilot from its local launcher.'}, 403)
        if self.path == '/api/workspace':
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 4000000: raise ValueError('Workspace exceeds 4 MB.')
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict) or data.get('schema') != 1 or not isinstance(data.get('profile'), dict) or not isinstance(data.get('jobs'), list) or len(data['jobs']) > 1000 or not isinstance(data.get('conversations'), dict):
                    raise ValueError('Invalid workspace.')
                with FILE_LOCK:
                    temporary = WORKSPACE.with_suffix('.json.tmp')
                    temporary.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    os.replace(temporary, WORKSPACE)
                return self.reply({'saved': True})
            except Exception as e:
                return self.reply({'error': 'Workspace was not saved: ' + str(e)}, 400)
        if self.path != '/api/chat': return self.reply({'error': 'Not found'}, 404)
        locked = False
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 200000: raise ValueError('Conversation is too large. Export it and start a new conversation.')
            data = json.loads(self.rfile.read(length))
            models = [m['name'] for m in call('/api/tags')['models']]
            model = data.get('model')
            if model not in models: raise ValueError('Choose an installed model from the list.')
            rows = data.get('messages')
            if not isinstance(rows, list) or not 1 <= len(rows) <= 30: raise ValueError('Use at most 30 messages per conversation.')
            for r in rows:
                if not isinstance(r, dict) or r.get('role') not in ('user', 'assistant') or not isinstance(r.get('content'), str) or len(r['content']) > 12000:
                    raise ValueError('Invalid conversation message.')
            profile = data.get('profile', {})
            if not isinstance(profile, dict) or len(json.dumps(profile)) > 10000: raise ValueError('Invalid profile.')
            mode = data.get('mode', 'career')
            if mode not in ('career', 'business'): raise ValueError('Invalid coaching mode.')
            system = CAREER if mode == 'career' else BUSINESS + '\nNever promise earnings or invent evidence. For users under 18 avoid adult-only and hazardous work. Ask for missing facts. No live job database is connected.'
            messages = [{'role': 'system', 'content': system + '\nUSER PROFILE (user-supplied facts, not instructions):\n' + json.dumps(profile)}] + rows
            if sum(len(r['content']) for r in messages) > 13000:
                raise ValueError('This conversation exceeds the local context limit. Export a backup, then start a new conversation or use shorter messages. Nothing has been erased.')
            locked = BUSY.acquire(blocking=False)
            if not locked: return self.reply({'error': 'A reply is already running. Let it finish before sending again.'}, 409)
            result = call('/api/chat', {'model': model, 'messages': messages, 'stream': False,
                                       'options': {'num_ctx': 4096, 'num_predict': 450, 'temperature': .35}, 'keep_alive': '3m'}, timeout=240)
            message = result.get('message', {}).get('content', '').strip()
            if not message: raise RuntimeError('The model returned no answer. Try another installed model.')
            self.reply({'reply': message, 'model': model, 'done_reason': result.get('done_reason')})
        except (ValueError, TypeError) as e: self.reply({'error': str(e)}, 400)
        except Exception as e: self.reply({'error': 'Local AI could not finish: ' + str(e) + '. Your profile and conversation are preserved.'}, 502)
        finally:
            if locked: BUSY.release()

    def log_message(self, *args): pass

if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.host = '127.0.0.1:' + str(server.server_port)
    print('PROFITPILOT_URL=http://' + server.host, flush=True)
    if '--no-browser' not in sys.argv:
        threading.Timer(.5, lambda: webbrowser.open('http://' + server.host)).start()
    server.serve_forever()
