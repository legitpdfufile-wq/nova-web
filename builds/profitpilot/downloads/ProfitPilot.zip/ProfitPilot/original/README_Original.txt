PROFITPILOT — HOW TO PUT THE WORKING APP TOGETHER
=================================================

This is the WORKING version of ProfitPilot.
You are NOT coding anything. You are NOT building anything.
You are just putting the files in the right place so the app runs.

FILES INCLUDED
--------------
1. profitpilot.html   → the app you open
2. Modelfile          → the AI brain
3. README.txt         → this guide

-------------------------------------------------
STEP 1 — INSTALL OLLAMA (REQUIRED)
-------------------------------------------------
1) Go to https://ollama.com
2) Download and install Ollama for Windows
3) Open Ollama once so it starts running in the background

-------------------------------------------------
STEP 2 — PUT THE APP TOGETHER
-------------------------------------------------
1) Put BOTH of these files in the SAME folder:
      - profitpilot.html
      - Modelfile

2) RIGHT‑CLICK inside that folder (NOT on a file).
   A menu will pop up.

3) Click:
      “Open in Terminal”
   or
      “Open PowerShell window here”

4) A blue or black terminal window will open IN that folder.

5) Type this EXACT command and press Enter:

      ollama create profitpilot -f Modelfile

This installs the ProfitPilot AI model on your computer.
You only do this ONE time.

-------------------------------------------------
STEP 3 — RUN THE WORKING APP
-------------------------------------------------
1) Make sure Ollama is running
2) Double‑click profitpilot.html
3) It will open in your browser
4) Type anything — the app will respond using your AI model

-------------------------------------------------
TROUBLESHOOTING
-------------------------------------------------
If you see:
“Error – is Ollama running on port 11434?”

Check:
- Did you install Ollama?
- Did you run the model creation command?
- Are both files in the same folder?
- Try closing and reopening Ollama

-------------------------------------------------
YOU NOW HAVE A FULLY WORKING APP
-------------------------------------------------
No coding.
No assembling.
No extra steps.
Just install Ollama → right‑click → open terminal → run command → open the app.
