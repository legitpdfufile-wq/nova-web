PROFITPILOT — CAREER BUILDER AND JOB SEARCH WORKSPACE

START
Extract the entire ZIP. On Windows, double-click START_PROFITPILOT.bat.
Keep its launcher window open while using the app. Your default browser opens
the private local workspace. Python is bundled; no Python setup is needed.

WHAT WORKS WITHOUT AI
Create a career-direction shortlist based on your selected interests and
experience; these are transparent starting suggestions, not an AI assessment.
Open job-board searches for your city. Load actual remote listings from Jobicy,
filter loaded roles, follow the original source link, save openings and track
Saved / Applied / Interview / Offer / Closed, dates and notes. Internet access
is required for job feeds and external searches. Jobicy responses are cached
for an hour. Up to 200 recent remote listings are loaded, displayed 10 at a time.
This is not an exhaustive job database. Confirm requirements and availability
on the original listing. A source failure is shown as a failure, never fake jobs.

LOCAL AI COACH
Have Ollama running at its normal local address, with a compatible chat model
already installed. The app discovers models; it does not create a fake model
alias, install models, change Ollama settings or use paid OpenAI services.
This computer's actual two-turn check used the installed llama3.2:3b model.
Choose a model in Your local coach. Replies use your profile and conversation
history. Export and start a new conversation when the context limit is reached.
Large models can be slow; a failed request is shown honestly with retry available.
The career coach cannot independently browse job boards. Use Discuss with local
coach on a Jobicy posting, or paste an actual listing. It drafts and advises;
it never sends applications or contacts employers. Review AI output yourself.
Original business-ideas coaching remains a separate selectable mode, with the
original prompt preserved. No earnings, hiring or eligibility are guaranteed.

KEEP YOUR WORK
The Windows edition saves profile, applications and conversations in
app/PRIVATE_WORKSPACE.json, surviving relaunch and a changed local browser address.
Export backup downloads a portable JSON containing your personal workspace.
Restore replaces current data after confirmation. Keep backups private.
The browser edition stores progress in its browser profile; export before
clearing browser data or switching devices. Job feed cache is not personal
profile data and is not included in workspace backups.

TRY ONLINE
https://legitpdfufile-wq.github.io/nova-web/builds/profitpilot/
The public edition has the planner, real remote feed, application tracker and
backup controls. AI coaching requires this local download and your own model;
the demo never presents a canned answer as a live AI reply.

SOURCE AND PRESERVATION
app contains editable source. original preserves the three former product files
and instructions for reference; they are not the maintained launcher. Original
HTML had no conversation history and required an absent profitpilot model name.
The maintained interface and same-origin bridge fix those paths. The larger
Studio Brain package and accepted workflows were not modified for this product.
Python runtime notices are in runtime/LICENSE.txt. Job listings remain their
owners' content; Jobicy attribution and original listing links are preserved.
